public class MainClass {

	public static void main(String[] args) {
		PhaseOneProject object=new PhaseOneProject();
		object.program();

	}

}